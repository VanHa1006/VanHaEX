package com.example.StudentTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
